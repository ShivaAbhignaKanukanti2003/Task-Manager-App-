from flask import Flask, render_template
from .config import Config
from .extensions import db, jwt

def create_app():
    app = Flask(
        __name__,
        template_folder="../templates",
        static_folder="../static"
    )
     
    app.config.from_object(Config)

    db.init_app(app)
    jwt.init_app(app)

    # Register blueprints
    from .routes.auth import auth_bp
    from .routes.tasks import task_bp

    app.register_blueprint(auth_bp, url_prefix="/api/auth")
    app.register_blueprint(task_bp, url_prefix="/api/tasks")

    # UI route (must be INSIDE create_app)
    @app.route("/")
    def home():
        return render_template("index.html")

    return app
