from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.extensions import db
from app.models.task import Task

task_bp = Blueprint("tasks", __name__)

@task_bp.route("/", methods=["GET", "POST"])
@jwt_required()
def tasks():
    user_id = get_jwt_identity()

    if request.method == "POST":
        data = request.get_json()
        if not data or "title" not in data:
            return jsonify(error="Task title required"), 400

        task = Task(title=data["title"], user_id=user_id)
        db.session.add(task)
        db.session.commit()

        return jsonify(message="Task created", task_id=task.id), 201

    tasks = Task.query.filter_by(user_id=user_id).all()
    return jsonify([
        {
            "id": t.id,
            "title": t.title,
            "completed": t.completed,
            "created_at": t.created_at.isoformat()
        }
        for t in tasks
    ]), 200
