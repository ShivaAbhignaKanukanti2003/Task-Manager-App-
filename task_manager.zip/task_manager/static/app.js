let token = localStorage.getItem("token") || "";

// ---------- LOGIN ----------
window.login = async function () {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (!res.ok) {
        alert("Login failed");
        return;
    }

    token = data.access_token;
    localStorage.setItem("token", token);

    const loginDiv = document.getElementById("loginSection");
    const appDiv = document.getElementById("appSection");

    if (loginDiv && appDiv) {
        loginDiv.style.display = "none";
        appDiv.style.display = "block";
    }

    loadTasks();
};

// ---------- LOGOUT ----------
window.logout = function () {
    localStorage.removeItem("token");
    token = "";
    location.reload();
};

// ---------- CREATE TASK ----------
window.createTask = async function () {
    const title = document.getElementById("taskTitle").value.trim();

    if (!title) {
        alert("Task title cannot be empty");
        return;
    }

    await fetch("/api/tasks/", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ title })
    });

    document.getElementById("taskTitle").value = "";
    loadTasks();
};

// ---------- TOGGLE COMPLETE ----------
window.toggleTask = async function (id, completed) {
    await fetch(`/api/tasks/${id}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ completed: !completed })
    });

    loadTasks();
};

// ---------- DELETE TASK ----------
window.deleteTask = async function (id) {
    await fetch(`/api/tasks/${id}`, {
        method: "DELETE",
        headers: {
            "Authorization": "Bearer " + token
        }
    });

    loadTasks();
};

// ---------- LOAD TASKS (FIXED VERSION) ----------
window.loadTasks = async function () {
    const res = await fetch("/api/tasks/", {
        headers: {
            "Authorization": "Bearer " + token
        }
    });

    if (!res.ok) {
        alert("Failed to load tasks");
        return;
    }

    const tasks = await res.json();
    const list = document.getElementById("taskList");
    list.innerHTML = "";

    tasks.forEach(task => {
        const li = document.createElement("li");

        li.innerHTML = `
            <span>
                ${task.title}
                ${task.completed ? "✅" : ""}
            </span>
            <div>
                <button onclick="toggleTask(${task.id}, ${task.completed})">✔</button>
                <button onclick="deleteTask(${task.id})">🗑</button>
            </div>
        `;

        list.appendChild(li);
    });
};

// ---------- AUTO-LOGIN ON REFRESH ----------
window.onload = function () {
    if (token) {
        const loginDiv = document.getElementById("loginSection");
        const appDiv = document.getElementById("appSection");

        if (loginDiv && appDiv) {
            loginDiv.style.display = "none";
            appDiv.style.display = "block";
        }

        loadTasks();
    }
};
